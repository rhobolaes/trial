package com.example.myapplication;

public class Accounts {

    private String username;

    public Accounts(){

    }

    public Accounts(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
}


