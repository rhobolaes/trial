package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

public class Resetpass extends AppCompatActivity {

    private String uId, uUsername, uPassword;
    private Button update;
    private TextView tUsername;
    private EditText ePassword;
    FirebaseFirestore db;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resetpass);
        db = FirebaseFirestore.getInstance();
        update =findViewById(R.id.reset_pass);
        tUsername=findViewById(R.id.textUsername);
        ePassword=findViewById(R.id.updatePassword);
        progressBar = findViewById(R.id.progress_Bar);
        Bundle bundle = getIntent().getExtras();
        if(bundle != null) {
            uUsername = bundle.getString("uUsername");
            uPassword = bundle.getString("uPassword");
            tUsername.setText(uUsername);
            ePassword.setText(uPassword);

            update.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String uusername = uUsername;
                    String password= ePassword.getText().toString();
                    Bundle bundle1 = getIntent().getExtras();
                    if(bundle1 != null){
                        progressBar.setVisibility(View.VISIBLE);
                        updateToFirestore(uusername, password);
                    }else {
                        Toast.makeText(Resetpass.this, "Error! " , Toast.LENGTH_SHORT).show();
                    }
                }
            });


        }
    }
    private void updateToFirestore(String username, String password){
        db.collection("accounts").document(username).update("password", password).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(Resetpass.this, "Data Updated", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(),SecondActivity.class));
                }else{
                    Toast.makeText(Resetpass.this, "Error : " +task.getException(), Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Resetpass.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}