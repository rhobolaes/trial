package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;

public class UpdateItem extends AppCompatActivity {
    private TextView uDisplayDate;
    private DatePickerDialog.OnDateSetListener onDateSetListener;
    private String uId, Uitemname, Uitemquantity, Udate;
    private Button updateItem;
    private EditText uItemname, uItemquantity;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    private ProgressBar uprogressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_item);
        uDisplayDate = (TextView) findViewById(R.id.updatetvDate);
        updateItem = (Button) findViewById(R.id.update_item_to_inventory);
        uItemname = (EditText) findViewById(R.id.updateItemName);
        uItemquantity = (EditText) findViewById(R.id.updateItemQuantity);
        uprogressBar = (ProgressBar) findViewById(R.id.update_invent_progress);
        Bundle inventbundle = getIntent().getExtras();
        uDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(UpdateItem.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth, onDateSetListener, year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        onDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1 ;
                String date = month + "/" + dayOfMonth + "/" + year;
                uDisplayDate.setText(date);
            }
        };

        if(inventbundle != null) {
            uId = inventbundle.getString("uId");
            Uitemname = inventbundle.getString("uItemname");
            Uitemquantity = inventbundle.getString("uItemquantity");
            Udate = inventbundle.getString("uDate");
            uItemname.setText(Uitemname);
            uItemquantity.setText(Uitemquantity);
            uDisplayDate.setText(Udate);

            updateItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String itemname = uItemname.getText().toString().trim();
                    String itemquantity = uItemquantity.getText().toString().trim();
                    String date = uDisplayDate.getText().toString().trim();
                    Bundle inventbundle1 = getIntent().getExtras();
                    if(inventbundle1 != null){
                        String id = uId;
                        uprogressBar.setVisibility(View.VISIBLE);
                        updateItemToFirestore(id, itemname, itemquantity, date);
                    }else {
                        Toast.makeText(UpdateItem.this, "Error! " , Toast.LENGTH_SHORT).show();
                    }
                }
            });


        }
    }
    private void updateItemToFirestore(String id, String itemname, String itemquantity, String date){
        db.collection("inventory").document(id).update("itemname", itemname,"itemquantity", itemquantity, "date", date).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(UpdateItem.this, "Data Updated", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(),InventoryInterface.class));
                }else{
                    Toast.makeText(UpdateItem.this, "Error : " +task.getException(), Toast.LENGTH_SHORT).show();
                    uprogressBar.setVisibility(View.GONE);
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(UpdateItem.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}