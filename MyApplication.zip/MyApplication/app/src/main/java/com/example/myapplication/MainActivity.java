package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

public class MainActivity extends AppCompatActivity {

    private EditText Name;
    private EditText Password;
    private TextView Info;
    private Button Login;
    private int counter = 5;
    private FirebaseFirestore firestore =FirebaseFirestore.getInstance();
    private DocumentReference adminAcc;
    private DocumentReference userAcc;


    @Override
    protected void onStart() {
        super.onStart();

        SessionManagement sessionManagement = new SessionManagement(MainActivity.this);
        String userID = sessionManagement.getSession();

        if(userID != "-1"){
            if(userID == "ADMIN-ACCOUNTS"){
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);
            }
            if(userID == "ADMIN-INVENTORY"){
                Intent intent = new Intent(MainActivity.this, InventoryInterface.class);
                startActivity(intent);
            }
            if(userID == "ADMIN-CANTEEN"){

            }
            else
            {

            }
        }else{

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name = (EditText)findViewById(R.id.etName);
        Password = (EditText)findViewById(R.id.etPassword);
        Info = (TextView)findViewById(R.id.tvlInfo);
        Login = (Button)findViewById(R.id.btnLogin);
        Info.setText("No of attempts remaining: 5");



        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(Name.getText().toString(), Password.getText().toString());
            }

        });
    }

    private void validate(String userName, String userPassword){
        String username = Name.getText().toString().trim();
        String password = Password.getText().toString().trim();
        if(TextUtils.isEmpty(username)){
            Name.setError("Email is Required.");
            return;
        }
        if(TextUtils.isEmpty(password)){
            Password.setError("Password is Required.");
            return;
        }
        if(password.length() < 6) {
            Password.setError("Password must be >= 6 Characters");
        }
        if(username != "" && password != ""){
            firestore.collection("admin_accounts").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    if(task.isSuccessful()){
                        for(DocumentSnapshot data : task.getResult()){
                            String a = data.getString("username");
                            String b = data.getString("password");
                            if(a.equalsIgnoreCase(username) && b.equalsIgnoreCase(password)){
                                if(a.equalsIgnoreCase("Admin")){

                                    User user =new User("ADMIN-ACCOUNTS", "Admin");
                                    SessionManagement sessionManagement = new SessionManagement(MainActivity.this);
                                    sessionManagement.saveSession(user);
                                    Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                                    startActivity(intent);
                                }
                                if(a.equalsIgnoreCase("Admin_canteen")){
                                    User user =new User("ADMIN-CANTEEN", "Admin_canteen");
                                    SessionManagement sessionManagement = new SessionManagement(MainActivity.this);
                                    sessionManagement.saveSession(user);
                                    Intent intent = new Intent(MainActivity.this, Registration.class);
                                    startActivity(intent);
                                }
                                if(a.equalsIgnoreCase("Admin_inventory"))
                                {
                                    User user =new User("ADMIN-INVENTORY", "Admin_inventory");
                                    SessionManagement sessionManagement = new SessionManagement(MainActivity.this);
                                    sessionManagement.saveSession(user);
                                    Intent intent = new Intent(MainActivity.this, InventoryInterface.class);
                                    startActivity(intent);
                                }
                            }
                        }
                    }
                }
            });

            firestore.collection("accounts").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    if(task.isSuccessful()){
                        for(DocumentSnapshot doc : task.getResult()) {
                            String c = doc.getString("username");
                            String d = doc.getString("password");
                            if(c.equalsIgnoreCase(username) && d.equalsIgnoreCase(password)){
                                User user =new User(username, username);
                                SessionManagement sessionManagement = new SessionManagement(MainActivity.this);
                                sessionManagement.saveSession(user);
                                Intent intent = new Intent(MainActivity.this, Resetpass.class);
                                startActivity(intent);
                            }

                        }
                    }
                }

            });
        }
        else{
            counter--;

            Info.setText("No of attempts remaining: " + String.valueOf(counter));

            if(counter == 0){
                Login.setEnabled(false);
            }
        }

    }
}